---
layout: page
title: Links
description: 没有链接的博客是孤独的
keywords: 友情链接
comments: false
menu: 链接
permalink: /links/
---

> God made relatives. Thank God we can choose our friends.

* [剥洋葱](http://liujinyuan.com.cn/){:target="_blank"}