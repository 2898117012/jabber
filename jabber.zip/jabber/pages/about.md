---
layout: page
title: About
description: 全汝形，抱汝生，勿使汝思虑营营！
keywords: php,laravel,thinkphp,vagrant, jabber
comments: false
menu: 关于
permalink: /about/
---

全汝形，抱汝生，勿使汝思虑营营！

仰慕「优雅编码的艺术」。

## 坚信

* 熟能生巧
* 努力改变人生

## 联系

* GitHub：[@2898117012](https://github.com/2898117012)
* QQ : [2898117012](http://user.qzone.qq.com/2898117012)

## Skill Keywords

#### Software Engineer Keywords
<div class="btn-inline">
    {% for keyword in site.skill_software_keywords %}
    <button class="btn btn-outline" type="button">{{ keyword }}</button>
    {% endfor %}
</div>

#### Mobile Developer Keywords
<div class="btn-inline">
    {% for keyword in site.skill_mobile_app_keywords %}
    <button class="btn btn-outline" type="button">{{ keyword }}</button>
    {% endfor %}
</div>

#### Windows Developer Keywords
<div class="btn-inline">
    {% for keyword in site.skill_windows_keywords %}
    <button class="btn btn-outline" type="button">{{ keyword }}</button>
    {% endfor %}
</div>
